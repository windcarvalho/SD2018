package br.ufc.sd.exemplo3;

public class AlunoInexistenteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
