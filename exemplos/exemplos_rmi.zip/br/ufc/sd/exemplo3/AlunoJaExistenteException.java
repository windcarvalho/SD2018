package br.ufc.sd.exemplo3;

public class AlunoJaExistenteException extends Exception {

}
