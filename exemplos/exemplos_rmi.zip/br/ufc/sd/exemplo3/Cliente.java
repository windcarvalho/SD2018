package br.ufc.sd.exemplo3;

import java.rmi.NotBoundException;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;

public class Cliente {
	
	public static void main(String[] args) {
	    Registry reg =  null;
	    try {
		   reg = LocateRegistry.getRegistry(8888);
	    } catch (RemoteException e) {
		    try {
			    reg = LocateRegistry.createRegistry(8888);
		    } catch (RemoteException e1) {
			    e1.printStackTrace();
			    System.exit(0);
			}
		}
	    try {
			ServidorAlunos servidor = (ServidorAlunos) reg.lookup("ServidorAlunos");
			Endereco e = new Endereco("Rua 1", "123", "PICI", "Fortaleza", "CE");
			Endereco e2 = new Endereco("Rua 112", "1-A", "Edson Queiroz", "Fortaleza", "CE");
			Aluno aluno1 = new Aluno("123", "Maria", e);
			Aluno aluno2 = new Aluno("124", "João", e2);
			
			try {
				servidor.adicionar(aluno1);
			} catch (AlunoJaExistenteException e1) {
				System.out.println("Aluno já cadastrado com matrícula " + aluno1.getMatricula());
			}

			try {
				servidor.adicionar(aluno2);
			} catch (AlunoJaExistenteException e1) {
				System.out.println("Aluno já cadastrado com matrícula " + aluno2.getMatricula());
			}
			
			List<Aluno> alunos = servidor.listar();
			for (Aluno a : alunos) {
				System.out.println(a);
			}
			

	    } catch (RemoteException | NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
