package br.ufc.sd.exemplo3;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface ServidorAlunos extends Remote {
	
	public void adicionar(Aluno aluno) throws AlunoJaExistenteException, 
	RemoteException;
	
	public Aluno consultar(String matricula) throws AlunoInexistenteException, 
	RemoteException;
	
	public void remover(String matricula) throws AlunoInexistenteException, 
	RemoteException;
	
	public void alterar(Aluno aluno) throws AlunoInexistenteException, 
	RemoteException;
	
	public List<Aluno> listar() throws RemoteException;
	

}
