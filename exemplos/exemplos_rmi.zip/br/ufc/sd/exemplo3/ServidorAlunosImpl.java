package br.ufc.sd.exemplo3;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.Vector;

public class ServidorAlunosImpl implements ServidorAlunos {
	
	public ServidorAlunosImpl() {
		super();
	}

	private static final long serialVersionUID = 1L;

	private List<Aluno> alunos = new Vector<Aluno>();
	
	public Aluno consultar(String matricula) throws AlunoInexistenteException, RemoteException {
		Aluno ret = null;
		for (Aluno a :alunos){
			if (a.getMatricula().equals(matricula)){
				ret = a;
				break;
			}
		}
		if (ret ==  null){
			throw new AlunoInexistenteException();
		}
		return ret;
	}

	public void adicionar(Aluno aluno) throws AlunoJaExistenteException, RemoteException {		
		try {
			consultar(aluno.getMatricula());
			throw new AlunoJaExistenteException();
		} catch (AlunoInexistenteException e) {
			alunos.add(aluno);
			System.out.println("Aluno "+ aluno + " adicionado");
		}
	}


	public void remover(String matricula) throws AlunoInexistenteException, RemoteException {
		Aluno a = consultar(matricula);
		alunos.remove(a);
		System.out.println("Aluno matricula "+ matricula+" excluido");
	}

	@Override
	public void alterar(Aluno aluno) throws AlunoInexistenteException, RemoteException {
		Aluno a = consultar(aluno.getMatricula());
		alunos.remove(a);
		alunos.add(aluno);
		System.out.println("Dados do aluno matricula "+ aluno.getMatricula()+" alterados");
	}

	@Override
	public List<Aluno> listar() throws RemoteException {
		System.out.println("Retornando lista de alunos");
		return alunos;
	}
	
	public static void main(String[] args) throws RemoteException {
		String nome = "ServidorAlunos";
		ServidorAlunos serv = new ServidorAlunosImpl();
		Remote stub = (ServidorAlunos) UnicastRemoteObject.exportObject(serv, 0);
		try {
//			stub = (Servidor) UnicastRemoteObject.exportObject(serv, 0);
			Registry reg = null;
			try {
				reg = LocateRegistry.createRegistry(8888);
			} catch (RemoteException e1) {
				reg = LocateRegistry.getRegistry(8888);
			}
			reg.rebind(nome, stub);
			System.out.println("Servidor em operação");
		} catch (RemoteException e) {
			e.printStackTrace();
		}

	}

}
