package br.ufc.sd.exemplo2;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Servidor extends Remote {
	
	public int soma (int a, int b) throws RemoteException;
	
	public String getUltimaOperacao() throws RemoteException;
	


}
