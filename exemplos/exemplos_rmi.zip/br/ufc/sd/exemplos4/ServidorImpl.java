package br.ufc.sd.exemplos4;

import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Vector;
import java.util.Random;

/**
 * <p>
 * Title:
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company:
 * </p>
 * 
 * @author not attributable
 * @version 1.0
 */

public class ServidorImpl implements Runnable, Servidor {

	private Vector listaClientes; // tracks all connected clients
	private Cliente cliente;
	private Vector listaMensagens; // maintains updatable list of quotes
	private Cliente cliente_tmp;
	private Thread clienteThread = null;
	private static int contador = 0;
	boolean flag_stop = false;

	public ServidorImpl() {
		listaMensagens = new Vector();
		listaMensagens.addElement("Esta mensagem eh um teste");
		listaMensagens.addElement("Esta mensagem eh tambem eh teste");
		listaClientes = new Vector();
	}

	public void run() {
		while (!flag_stop) {
			try {
				// sleep for a second
				Thread.currentThread().sleep(1000);
			} catch (Exception e) {
			}
			atualizaClientes();
		}
		flag_stop = false;
	}

	private void atualizaClientes() {
		synchronized (listaClientes) {
			Vector backup = (Vector) listaClientes.clone();
			int seed;
			while ((seed = new Random().nextInt()) <= 0)
				;
			seed = seed % listaMensagens.size();
			String data = listaMensagens.elementAt(seed) + ": " + ++contador;
			for (int i = 0; i < listaClientes.size(); i++) {
				cliente_tmp = (Cliente) listaClientes.elementAt(i);
				try {
					// Atualiza o cliente, via callback
					cliente_tmp.atualizaClient((String) data);
				} catch (RemoteException e) {
					System.out.println("cliente deve ter sido disconectado !");
					// retira a referencia do cliente que foi disconectado
					backup.removeElement(cliente_tmp);
					if (backup.size() <= 0) {
						// no more clients- so stop server thread
						listaClientes = (Vector) backup.clone();
						this.flag_stop = true;
						// Thread dummy = clientThread;
						// clientThread = null;
						// dummy.stop();
					}
				}
			}
			listaClientes = (Vector) backup.clone();
		} // end syncronization on clientele
	}

	public void adicionaMensagem(String mensagem) throws RemoteException {
		synchronized (listaMensagens) {
			listaMensagens.addElement(mensagem);
		}
	}

	public void registraCliente(Cliente c) throws RemoteException {
		synchronized (listaClientes) {
			listaClientes.addElement(c);
		}
		if (clienteThread == null) {
			clienteThread = new Thread(this, "clienteThread");
			clienteThread.start();
		}
	}

	public static void main(String[] args) {
//		System.setSecurityManager(new RMISecurityManager());
		try {
			System.out.println("Criando registry...");
			Registry reg = null;
			try {
				reg = LocateRegistry.createRegistry(8099);
			} catch (Exception ex) {
				try {
					reg = LocateRegistry.getRegistry(8099);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			System.out.println("Criando servidor...");
			ServidorImpl servidor = new ServidorImpl();
			Servidor stub_servidor = (Servidor) UnicastRemoteObject.exportObject(servidor,0);
			System.out.println("Ligando servidor ao Registry...");
			// Naming.rebind("rmi://localhost:8099/Servidor", servidor);
			reg.rebind("Servidor", stub_servidor);
			System.out.println("Servidor ligado ao Registry");
		} catch (Exception e) {
			System.out.println("Problema ao conectar servidor no Regitry (binding)");
			System.out.println(e.toString());
		}
	}

}