package br.ufc.sd.exemplo1;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Vector;

public class ServidorImpl implements Servidor {
	
	private String ultimaOperacao = "Nenhuma";
	private int numeroRequests = 0;
	
	public ServidorImpl() {
		super();
	}
	
	private void printNumRequests(){
		numeroRequests++;
		System.out.println("Numero Pedidos: "+ numeroRequests);
	}

	public int soma(int a, int b) throws RemoteException {
		ultimaOperacao = a + " + " + b + " = " + (a+b);
		printNumRequests();
		return a + b;
	}
	
	

	public static void main(String[] args) {
		String nome = "Servidor";
		Remote serv = new ServidorImpl();
		Servidor stub = null;
		try {
			stub = (Servidor) 
					UnicastRemoteObject.exportObject(serv, 0);
			Registry reg = null;
			try {
				reg = LocateRegistry.createRegistry(8888);
			} catch (RemoteException e1) {
				reg = LocateRegistry.getRegistry(8888);
			}
			reg.rebind(nome, stub);
			System.out.println("Servidor em operação");
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	@Override
	public String getUltimaOperacao() throws RemoteException {
		printNumRequests();
		return ultimaOperacao;
	}


	Vector pessoas = new Vector();
	
	public void incluir(Pessoa pessoa) throws RemoteException {
		pessoas.add(pessoa);
		System.out.println("Numero de pessoas cadastradas = " + pessoas.size());
		
	}
	
	
	
	
	
	
	
	
	
}
