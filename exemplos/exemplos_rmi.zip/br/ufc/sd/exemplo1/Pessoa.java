package br.ufc.sd.exemplo1;

import java.io.Serializable;

public class Pessoa implements Serializable{
	
	private String nome;
	private String cpf;
	
	public Pessoa(String n, String c){
		this.nome = n;
		this.cpf = c;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	

}
