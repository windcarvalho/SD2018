package br.ufc.sd.exemplo1;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Cliente2 {
	
	public static void main(String[] args) {
	    Registry reg =  null;
	    try {
		   reg = LocateRegistry.getRegistry(8888);
	    } catch (RemoteException e) {
		    try {
			    reg = LocateRegistry.createRegistry(8888);
		    } catch (RemoteException e1) {
			    e1.printStackTrace();
			    System.exit(0);
			}
		}
	    try {
			Servidor servidor = (Servidor) reg.lookup("Servidor");
			System.out.println(servidor.getUltimaOperacao());
		} catch (RemoteException | NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
